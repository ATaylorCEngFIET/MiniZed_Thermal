/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xgpiops.h"
#include "xspips.h"
#include "ST7789.h"
#include "xiicps.h"
#include "mlx90640_api.h"

static XSpiPs SpiInstance_EMIO;
static XGpioPs Gpio; //GPIO
static XIicPs Iic;

#define IIC_SLAVE_ADDR		0x33
#define IIC_SCLK_RATE		100000

#define SPI_EMIO			XPAR_XSPIPS_0_DEVICE_ID
#define IIC_DEVICE_ID		XPAR_XIICPS_0_DEVICE_ID

#define BL 55
#define DC 54
#define WIDTH 32
#define HEIGHT 24

#define TEST_BUFFER_SIZE	512
#define TA_SHIFT 8


static void ST7789_WriteCommand(uint8_t cmd);
static void ST7789_WriteData(uint8_t *buff, size_t buff_size);
static void ST7789_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
static void ST7789_WriteSmallData(uint8_t data);
void ST7789_Init(void);
void ST7789_Fill_Color(uint16_t color);
void ST7789_SetRotation(uint8_t m);
int MLX90640_I2CRead(uint8_t slaveAddr, uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data);
int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data);
void ST7789_Fill_Display(float *mlx90640Frame);
void ST7789_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
long map(long x, long in_min, long in_max, long out_min, long out_max);


u8 SendBuffer[TEST_BUFFER_SIZE];    //I2C TX
u8 RecvBuffer[TEST_BUFFER_SIZE];    //I2C RX

u16 frame[WIDTH][HEIGHT];

const uint16_t camColors[] = {0x480F,
0x400F,0x400F,0x400F,0x4010,0x3810,0x3810,0x3810,0x3810,0x3010,0x3010,
0x3010,0x2810,0x2810,0x2810,0x2810,0x2010,0x2010,0x2010,0x1810,0x1810,
0x1811,0x1811,0x1011,0x1011,0x1011,0x0811,0x0811,0x0811,0x0011,0x0011,
0x0011,0x0011,0x0011,0x0031,0x0031,0x0051,0x0072,0x0072,0x0092,0x00B2,
0x00B2,0x00D2,0x00F2,0x00F2,0x0112,0x0132,0x0152,0x0152,0x0172,0x0192,
0x0192,0x01B2,0x01D2,0x01F3,0x01F3,0x0213,0x0233,0x0253,0x0253,0x0273,
0x0293,0x02B3,0x02D3,0x02D3,0x02F3,0x0313,0x0333,0x0333,0x0353,0x0373,
0x0394,0x03B4,0x03D4,0x03D4,0x03F4,0x0414,0x0434,0x0454,0x0474,0x0474,
0x0494,0x04B4,0x04D4,0x04F4,0x0514,0x0534,0x0534,0x0554,0x0554,0x0574,
0x0574,0x0573,0x0573,0x0573,0x0572,0x0572,0x0572,0x0571,0x0591,0x0591,
0x0590,0x0590,0x058F,0x058F,0x058F,0x058E,0x05AE,0x05AE,0x05AD,0x05AD,
0x05AD,0x05AC,0x05AC,0x05AB,0x05CB,0x05CB,0x05CA,0x05CA,0x05CA,0x05C9,
0x05C9,0x05C8,0x05E8,0x05E8,0x05E7,0x05E7,0x05E6,0x05E6,0x05E6,0x05E5,
0x05E5,0x0604,0x0604,0x0604,0x0603,0x0603,0x0602,0x0602,0x0601,0x0621,
0x0621,0x0620,0x0620,0x0620,0x0620,0x0E20,0x0E20,0x0E40,0x1640,0x1640,
0x1E40,0x1E40,0x2640,0x2640,0x2E40,0x2E60,0x3660,0x3660,0x3E60,0x3E60,
0x3E60,0x4660,0x4660,0x4E60,0x4E80,0x5680,0x5680,0x5E80,0x5E80,0x6680,
0x6680,0x6E80,0x6EA0,0x76A0,0x76A0,0x7EA0,0x7EA0,0x86A0,0x86A0,0x8EA0,
0x8EC0,0x96C0,0x96C0,0x9EC0,0x9EC0,0xA6C0,0xAEC0,0xAEC0,0xB6E0,0xB6E0,
0xBEE0,0xBEE0,0xC6E0,0xC6E0,0xCEE0,0xCEE0,0xD6E0,0xD700,0xDF00,0xDEE0,
0xDEC0,0xDEA0,0xDE80,0xDE80,0xE660,0xE640,0xE620,0xE600,0xE5E0,0xE5C0,
0xE5A0,0xE580,0xE560,0xE540,0xE520,0xE500,0xE4E0,0xE4C0,0xE4A0,0xE480,
0xE460,0xEC40,0xEC20,0xEC00,0xEBE0,0xEBC0,0xEBA0,0xEB80,0xEB60,0xEB40,
0xEB20,0xEB00,0xEAE0,0xEAC0,0xEAA0,0xEA80,0xEA60,0xEA40,0xF220,0xF200,
0xF1E0,0xF1C0,0xF1A0,0xF180,0xF160,0xF140,0xF100,0xF0E0,0xF0C0,0xF0A0,
0xF080,0xF060,0xF040,0xF020,0xF800,};

int main()
{
	XSpiPs_Config *SpiConfig_EMIO;
	XGpioPs_Config *GPIOConfigPtr;
	XIicPs_Config  *IICConfig;

    init_platform();

    print("Hello World\n\r");
    print("Successfully ran Hello World application\n\r");


    SpiConfig_EMIO = XSpiPs_LookupConfig((u16)SPI_EMIO);
	XSpiPs_CfgInitialize(&SpiInstance_EMIO, SpiConfig_EMIO,SpiConfig_EMIO->BaseAddress);
	XSpiPs_SetOptions(&SpiInstance_EMIO,XSPIPS_MASTER_OPTION |  XSPIPS_FORCE_SSELECT_OPTION	);
	XSpiPs_SetClkPrescaler(&SpiInstance_EMIO, XSPIPS_CLK_PRESCALE_256);

	IICConfig = XIicPs_LookupConfig(IIC_DEVICE_ID);
	XIicPs_CfgInitialize(&Iic, IICConfig, IICConfig->BaseAddress);
	XIicPs_SetSClk(&Iic, IIC_SCLK_RATE);
	//XIic_SetSClk(&Iic, IIC_SCLK_RATE);

	GPIOConfigPtr = XGpioPs_LookupConfig(XPAR_XGPIOPS_0_DEVICE_ID);
	XGpioPs_CfgInitialize(&Gpio, GPIOConfigPtr,GPIOConfigPtr->BaseAddr);

    //set direction and enable output
    XGpioPs_SetDirectionPin(&Gpio, DC, 1);
    XGpioPs_SetOutputEnablePin(&Gpio, DC, 1);

    XGpioPs_SetDirectionPin(&Gpio, BL, 1);
    XGpioPs_SetOutputEnablePin(&Gpio, BL, 1);

    XGpioPs_WritePin(&Gpio, BL, 1);
    XGpioPs_WritePin(&Gpio, DC, 1);

    ST7789_Init();



int status;
static u16 mlx90640Frame[834];
static uint16_t eeMLX90640[832];
paramsMLX90640 mlx90640;
static float mlx90640Image[768];
//int curResolution;
//float vdd;
float Ta;
float tr;
float emissivity = 0.95;
static float mlx90640To[768];

	MLX90640_DumpEE (0x33, eeMLX90640);
	MLX90640_ExtractParameters(eeMLX90640, &mlx90640);
    while(1){


    	MLX90640_GetFrameData(0x33,mlx90640Frame);
    	Ta = MLX90640_GetTa (mlx90640Frame, &mlx90640) - TA_SHIFT;
    	MLX90640_CalculateTo(mlx90640Frame, &mlx90640, emissivity, Ta, mlx90640To);
    	for(int i =0; i <24 ;i++){
    		for (int y= 0; y < 32; y++){
    			printf(" %.2f ", mlx90640To[y+(i*32)]);
    		}
    		printf("\n\r");
    	}
    	ST7789_Fill_Display(&mlx90640To);
    }
    cleanup_platform();
    return 0;
}

static void ST7789_WriteCommand(uint8_t cmd)
{

	XGpioPs_WritePin(&Gpio, DC, 0);
	XSpiPs_SetSlaveSelect(&SpiInstance_EMIO, 0x00);
	XSpiPs_PolledTransfer(&SpiInstance_EMIO, &cmd, NULL, sizeof(cmd));

}

static void ST7789_WriteData(uint8_t *buff, size_t buff_size)
{

	XGpioPs_WritePin(&Gpio, DC, 1);
	//XSpiPs_SetSlaveSelect(&SpiInstance_EMIO, 0x00);

	// split data in small chunks because HAL can't send more than 64K at once

	while (buff_size > 0) {
		uint16_t chunk_size = buff_size > 65535 ? 65535 : buff_size;
		XSpiPs_SetSlaveSelect(&SpiInstance_EMIO, 0x00);
		XSpiPs_PolledTransfer(&SpiInstance_EMIO, buff, NULL, chunk_size);
		//HAL_SPI_Transmit(&ST7789_SPI_PORT, buff, chunk_size, HAL_MAX_DELAY);
		buff += chunk_size;
		buff_size -= chunk_size;
	}

}

static void ST7789_WriteSmallData(uint8_t data)
{
	XGpioPs_WritePin(&Gpio, DC, 1);
	XSpiPs_SetSlaveSelect(&SpiInstance_EMIO, 0x00);
	XSpiPs_PolledTransfer(&SpiInstance_EMIO, &data, NULL, sizeof(data));


}


static void ST7789_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{

	uint16_t x_start = x0 + X_SHIFT, x_end = x1 + X_SHIFT;
	uint16_t y_start = y0 + Y_SHIFT, y_end = y1 + Y_SHIFT;

	/* Column Address set */
	ST7789_WriteCommand(ST7789_CASET);
	{
		uint8_t data[] = {x_start >> 8, x_start & 0xFF, x_end >> 8, x_end & 0xFF};
		ST7789_WriteData(data, sizeof(data));
	}

	/* Row Address set */
	ST7789_WriteCommand(ST7789_RASET);
	{
		uint8_t data[] = {y_start >> 8, y_start & 0xFF, y_end >> 8, y_end & 0xFF};
		ST7789_WriteData(data, sizeof(data));
	}
	/* Write to RAM */
	ST7789_WriteCommand(ST7789_RAMWR);
}

void ST7789_Init(void)
{

    usleep(50000);

    ST7789_WriteCommand(ST7789_COLMOD);		//	Set color mode
    ST7789_WriteSmallData(ST7789_COLOR_MODE_16bit);
  	ST7789_WriteCommand(0xB2);				//	Porch control
	{
		uint8_t data[] = {0x0C, 0x0C, 0x00, 0x33, 0x33};
		ST7789_WriteData(data, sizeof(data));
	}
	ST7789_SetRotation(ST7789_ROTATION);	//	MADCTL (Display Rotation)

	/* Internal LCD Voltage generator settings */
    ST7789_WriteCommand(0XB7);				//	Gate Control
    ST7789_WriteSmallData(0x35);			//	Default value
    ST7789_WriteCommand(0xBB);				//	VCOM setting
    ST7789_WriteSmallData(0x19);			//	0.725v (default 0.75v for 0x20)
    ST7789_WriteCommand(0xC0);				//	LCMCTRL
    ST7789_WriteSmallData (0x2C);			//	Default value
    ST7789_WriteCommand (0xC2);				//	VDV and VRH command Enable
    ST7789_WriteSmallData (0x01);			//	Default value
    ST7789_WriteCommand (0xC3);				//	VRH set
    ST7789_WriteSmallData (0x12);			//	+-4.45v (defalut +-4.1v for 0x0B)
    ST7789_WriteCommand (0xC4);				//	VDV set
    ST7789_WriteSmallData (0x20);			//	Default value
    ST7789_WriteCommand (0xC6);				//	Frame rate control in normal mode
    ST7789_WriteSmallData (0x0F);			//	Default value (60HZ)
    ST7789_WriteCommand (0xD0);				//	Power control
    ST7789_WriteSmallData (0xA4);			//	Default value
    ST7789_WriteSmallData (0xA1);			//	Default value
	/**************** Division line ****************/

	ST7789_WriteCommand(0xE0);
	{
		uint8_t data[] = {0xD0, 0x04, 0x0D, 0x11, 0x13, 0x2B, 0x3F, 0x54, 0x4C, 0x18, 0x0D, 0x0B, 0x1F, 0x23};
		ST7789_WriteData(data, sizeof(data));
	}

    ST7789_WriteCommand(0xE1);
	{
		uint8_t data[] = {0xD0, 0x04, 0x0C, 0x11, 0x13, 0x2C, 0x3F, 0x44, 0x51, 0x2F, 0x1F, 0x1F, 0x20, 0x23};
		ST7789_WriteData(data, sizeof(data));
	}
    ST7789_WriteCommand (ST7789_INVON);		//	Inversion ON
	ST7789_WriteCommand (ST7789_SLPOUT);	//	Out of sleep mode
  	ST7789_WriteCommand (ST7789_NORON);		//	Normal Display on
  	ST7789_WriteCommand (ST7789_DISPON);	//	Main screen turned on

	usleep(500000);
	ST7789_Fill_Color(BLACK);				//	Fill with Black.
}

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void ST7789_Fill_Display(float *mlx90640Frame)
{
	//834
	uint16_t i, j;
//	uint8_t data[2];
	float temp;
	u8 mapped;
	u16 colour;

	for (i = 0; i < 240; i++)
		for (j = 0; j < 320; j++) {

			temp = (mlx90640Frame[((i/10)*32)+(j/10)]);
			mapped = map((u16) temp, 0, 100, 0, 255);
			colour = camColors[mapped];
			ST7789_DrawPixel(0+i, 0+j, colour);

		}
	//ST7789_UnSelect();
}

void ST7789_DrawPixel(uint16_t x, uint16_t y, uint16_t color)
{
	if ((x < 0) || (x >= ST7789_WIDTH) ||
		 (y < 0) || (y >= ST7789_HEIGHT))	return;

	ST7789_SetAddressWindow(x, y, x, y);
	uint8_t data[] = {color >> 8, color & 0xFF};
	//ST7789_Select();
	ST7789_WriteData(data, sizeof(data));
	//ST7789_UnSelect();
}

void ST7789_Fill_Color(uint16_t color)
{
	uint16_t i, j;
	ST7789_SetAddressWindow(0, 0, ST7789_WIDTH - 1, ST7789_HEIGHT - 1);
	//ST7789_Select();
	//XSpiPs_SetSlaveSelect(&SpiInstance_EMIO, 0x00);

	for (i = 0; i < ST7789_WIDTH; i++)
		for (j = 0; j < ST7789_HEIGHT; j++) {
			uint8_t data[] = {color >> 8, color & 0xFF};
			ST7789_WriteData(data, sizeof(data));
		}
	//ST7789_UnSelect();
}

void ST7789_SetRotation(uint8_t m)
{
	ST7789_WriteCommand(ST7789_MADCTL);	// MADCTL
	switch (m) {
	case 0:
		ST7789_WriteSmallData(ST7789_MADCTL_MX | ST7789_MADCTL_MY | ST7789_MADCTL_RGB);
		break;
	case 1:
		ST7789_WriteSmallData(ST7789_MADCTL_MY | ST7789_MADCTL_MV | ST7789_MADCTL_RGB);
		break;
	case 2:
		ST7789_WriteSmallData(ST7789_MADCTL_RGB);
		break;
	case 3:
		ST7789_WriteSmallData(ST7789_MADCTL_MX | ST7789_MADCTL_MV | ST7789_MADCTL_RGB);
		break;
	default:
		break;
	}
}


int MLX90640_I2CRead(uint8_t slaveAddr,uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data)
{

    int cnt = 0;
    int i = 0;
    u8 cmd[2] = {0,0};
    u8 i2cData[1664] = {0};
    uint16_t *p;

    p = data;
    cmd[0] = startAddress >> 8;
    cmd[1] = startAddress & 0x00FF;
    XIicPs_SetOptions(&Iic,XIICPS_REP_START_OPTION);
	XIicPs_MasterSendPolled(&Iic, cmd,2, IIC_SLAVE_ADDR);
	//while (XIicPs_BusIsBusy(&Iic)) {
		/* NOP */
	//}

	XIicPs_MasterRecvPolled(&Iic, i2cData,2*nMemAddressRead, IIC_SLAVE_ADDR);
	while (XIicPs_BusIsBusy(&Iic)) {
		/* NOP */
	}
	XIicPs_ClearOptions(&Iic,XIICPS_REP_START_OPTION);

    for(cnt=0; cnt < nMemAddressRead; cnt++)
    {
        i = cnt << 1;
        *p++ = (uint16_t)i2cData[i]*256 + (uint16_t)i2cData[i+1];
    }

    return 0;
}



int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data)
{

    u8 cmd[4] = {0,0,0,0};
    static uint16_t dataCheck;


    cmd[0] = writeAddress >> 8;
    cmd[1] = writeAddress & 0x00FF;
    cmd[2] = data >> 8;
    cmd[3] = data & 0x00FF;

    XIicPs_MasterSendPolled(&Iic, cmd,4, IIC_SLAVE_ADDR);
    	while (XIicPs_BusIsBusy(&Iic)) {
    		/* NOP */
    	}


    MLX90640_I2CRead(slaveAddr,writeAddress,1, &dataCheck);

    if ( dataCheck != data)
    {
        return -2;
    }

    return 0;
}
